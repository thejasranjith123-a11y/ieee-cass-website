import { Linkedin, Instagram, ExternalLink } from "lucide-react"

const footerLinks = [
  {
    title: "Quick Links",
    links: [
      { label: "About Us", href: "#about" },
      { label: "Events", href: "#events" },
      { label: "Team", href: "#team" },
      { label: "Contact", href: "#contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "IEEE CASS Global", href: "https://ieee-cas.org", external: true },
      { label: "IEEE Kerala Section", href: "https://ieeekerala.org", external: true },
      { label: "Membership", href: "#contact" },
      { label: "Publications", href: "#" },
    ],
  },
]

export function Footer() {
  return (
    <footer className="bg-[var(--cass-navy)] text-white">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-12 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[var(--cass-green-primary)]">
                <span className="text-xl font-bold text-white">C</span>
              </div>
              <div>
                <p className="text-lg font-bold">IEEE CASS</p>
                <p className="text-sm text-white/70">Kerala Chapter</p>
              </div>
            </div>
            <p className="mt-4 max-w-md text-sm text-white/70 leading-relaxed">
              The IEEE Circuits and Systems Society (CASS) Kerala Chapter is
              dedicated to advancing circuits and systems technology through
              education, research, and professional development in Kerala.
            </p>
            {/* Social Links */}
            <div className="mt-6 flex gap-3">
              <a
                href="#"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-[var(--cass-green-primary)]"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-[var(--cass-green-primary)]"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://ieee.org"
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-[var(--cass-green-primary)]"
                aria-label="IEEE"
              >
                <ExternalLink className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                {section.title}
              </h3>
              <ul className="mt-4 space-y-3">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      target={link.external ? "_blank" : undefined}
                      rel={link.external ? "noopener noreferrer" : undefined}
                      className="inline-flex items-center gap-1 text-sm text-white/70 transition-colors hover:text-[var(--cass-green-secondary)]"
                    >
                      {link.label}
                      {link.external && (
                        <ExternalLink className="h-3 w-3" />
                      )}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 border-t border-white/10 pt-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-white/60">
              © {new Date().getFullYear()} IEEE CASS Kerala Chapter. All rights
              reserved.
            </p>
            <p className="text-sm text-white/60">
              Part of{" "}
              <a
                href="https://ieee.org"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--cass-green-secondary)] hover:underline"
              >
                IEEE
              </a>{" "}
              &{" "}
              <a
                href="https://ieeekerala.org"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--cass-green-secondary)] hover:underline"
              >
                IEEE Kerala Section
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
