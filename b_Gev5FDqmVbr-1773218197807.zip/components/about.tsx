import { Card, CardContent } from "@/components/ui/card"
import { Target, Eye, Lightbulb, Users, BookOpen, Award } from "lucide-react"

const features = [
  {
    icon: Lightbulb,
    title: "Innovation",
    description:
      "Fostering cutting-edge research and development in circuits and systems engineering.",
  },
  {
    icon: Users,
    title: "Community",
    description:
      "Building a vibrant network of professionals, researchers, and students across Kerala.",
  },
  {
    icon: BookOpen,
    title: "Education",
    description:
      "Providing world-class learning opportunities through workshops, seminars, and conferences.",
  },
  {
    icon: Award,
    title: "Excellence",
    description:
      "Recognizing and promoting outstanding contributions to the field of circuits and systems.",
  },
]

export function About() {
  return (
    <section id="about" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-block rounded-full bg-[var(--cass-green-primary)]/10 px-4 py-1.5 text-sm font-semibold text-[var(--cass-green-primary)]">
            About Us
          </span>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Advancing Circuits and Systems in Kerala
          </h2>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            The IEEE Circuits and Systems Society (CASS) is a global network of
            engineers, scientists, and students working in the broad areas of
            circuits, systems, signals, modeling, analysis, and design.
          </p>
        </div>

        {/* Vision & Mission Cards */}
        <div className="mt-16 grid gap-8 md:grid-cols-2">
          <Card className="group overflow-hidden border-none bg-gradient-to-br from-[var(--cass-green-primary)] to-[var(--cass-teal)] shadow-lg transition-transform hover:-translate-y-1">
            <CardContent className="p-8">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-white/20">
                <Eye className="h-7 w-7 text-white" />
              </div>
              <h3 className="mb-3 text-2xl font-bold text-white">Our Vision</h3>
              <p className="text-white/90 leading-relaxed">
                To be the leading professional society for advancing circuits
                and systems technology in Kerala, inspiring innovation and
                fostering collaboration among academia, industry, and research
                institutions to address global challenges.
              </p>
            </CardContent>
          </Card>

          <Card className="group overflow-hidden border-none bg-gradient-to-br from-[var(--cass-navy)] to-[var(--cass-green-primary)] shadow-lg transition-transform hover:-translate-y-1">
            <CardContent className="p-8">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-white/20">
                <Target className="h-7 w-7 text-white" />
              </div>
              <h3 className="mb-3 text-2xl font-bold text-white">Our Mission</h3>
              <p className="text-white/90 leading-relaxed">
                To promote the theory, design, and applications of circuits and
                systems through technical activities, publications, conferences,
                and educational programs that benefit the Kerala engineering
                community and beyond.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="group border border-border bg-card shadow-sm transition-all hover:border-[var(--cass-green-primary)]/30 hover:shadow-md hover:-translate-y-1"
            >
              <CardContent className="p-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-[var(--cass-green-primary)]/10 transition-colors group-hover:bg-[var(--cass-green-primary)]">
                  <feature.icon className="h-6 w-6 text-[var(--cass-green-primary)] transition-colors group-hover:text-white" />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
