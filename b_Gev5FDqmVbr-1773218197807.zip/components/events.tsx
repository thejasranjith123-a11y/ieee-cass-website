"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, Clock, ArrowRight } from "lucide-react"

const upcomingEvents = [
  {
    id: 1,
    title: "Analog Circuits Workshop 2026",
    date: "April 15-17, 2026",
    time: "9:00 AM - 5:00 PM",
    location: "College of Engineering, Trivandrum",
    description:
      "A comprehensive three-day workshop on modern analog circuit design techniques, covering operational amplifiers, signal conditioning, and low-power design methodologies.",
    category: "Workshop",
  },
  {
    id: 2,
    title: "VLSI Design Bootcamp",
    date: "May 5-10, 2026",
    time: "10:00 AM - 4:00 PM",
    location: "NIT Calicut",
    description:
      "Intensive bootcamp on VLSI design fundamentals, RTL coding, synthesis, and verification techniques with hands-on projects using industry-standard tools.",
    category: "Bootcamp",
  },
]

const pastEvents = [
  {
    id: 3,
    title: "Signal Processing Seminar",
    date: "February 20, 2026",
    time: "2:00 PM - 6:00 PM",
    location: "IIT Palakkad",
    description:
      "Expert talks on advanced signal processing algorithms, machine learning for signal analysis, and real-world applications in communication systems.",
    category: "Seminar",
  },
  {
    id: 4,
    title: "Embedded Systems Hands-on Workshop",
    date: "January 12-13, 2026",
    time: "9:30 AM - 5:30 PM",
    location: "CUSAT, Kochi",
    description:
      "Practical workshop on embedded systems design, covering microcontroller programming, sensor integration, and IoT applications with Arduino and ESP32.",
    category: "Workshop",
  },
]

function EventCard({
  event,
  isPast = false,
}: {
  event: (typeof upcomingEvents)[0]
  isPast?: boolean
}) {
  return (
    <Card
      className={`group overflow-hidden border transition-all hover:shadow-lg hover:-translate-y-1 ${
        isPast ? "opacity-80" : ""
      }`}
    >
      <CardContent className="p-0">
        {/* Category Badge */}
        <div className="relative">
          <div
            className={`px-6 py-3 ${
              isPast
                ? "bg-[var(--cass-grey)]"
                : "bg-gradient-to-r from-[var(--cass-green-primary)] to-[var(--cass-teal)]"
            }`}
          >
            <span className="inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-semibold text-white">
              {event.category}
            </span>
          </div>
        </div>

        <div className="p-6">
          <h3 className="mb-3 text-xl font-bold text-foreground group-hover:text-[var(--cass-green-primary)] transition-colors">
            {event.title}
          </h3>

          <div className="mb-4 space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4 text-[var(--cass-green-primary)]" />
              <span>{event.date}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4 text-[var(--cass-green-primary)]" />
              <span>{event.time}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 text-[var(--cass-green-primary)]" />
              <span>{event.location}</span>
            </div>
          </div>

          <p className="mb-6 text-sm text-muted-foreground leading-relaxed line-clamp-3">
            {event.description}
          </p>

          <Button
            variant={isPast ? "outline" : "default"}
            className={
              isPast
                ? "border-[var(--cass-grey)] text-[var(--cass-grey)] hover:bg-[var(--cass-grey)] hover:text-white"
                : "bg-[var(--cass-green-primary)] hover:bg-[var(--cass-green-primary)]/90 text-white"
            }
          >
            {isPast ? "View Details" : "Register Now"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export function Events() {
  const [activeTab, setActiveTab] = useState<"upcoming" | "past">("upcoming")

  return (
    <section id="events" className="py-20 lg:py-28 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-block rounded-full bg-[var(--cass-green-primary)]/10 px-4 py-1.5 text-sm font-semibold text-[var(--cass-green-primary)]">
            Events
          </span>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Workshops, Seminars & Conferences
          </h2>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            Join us for exciting events that bring together professionals,
            researchers, and students in the field of circuits and systems.
          </p>
        </div>

        {/* Tabs */}
        <div className="mt-12 flex justify-center">
          <div className="inline-flex rounded-lg border border-border bg-card p-1">
            <button
              onClick={() => setActiveTab("upcoming")}
              className={`rounded-md px-6 py-2 text-sm font-medium transition-all ${
                activeTab === "upcoming"
                  ? "bg-[var(--cass-green-primary)] text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Upcoming Events
            </button>
            <button
              onClick={() => setActiveTab("past")}
              className={`rounded-md px-6 py-2 text-sm font-medium transition-all ${
                activeTab === "past"
                  ? "bg-[var(--cass-green-primary)] text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Past Events
            </button>
          </div>
        </div>

        {/* Events Grid */}
        <div className="mt-10 grid gap-8 md:grid-cols-2">
          {activeTab === "upcoming"
            ? upcomingEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))
            : pastEvents.map((event) => (
                <EventCard key={event.id} event={event} isPast />
              ))}
        </div>
      </div>
    </section>
  )
}
