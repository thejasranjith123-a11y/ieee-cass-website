import { Card, CardContent } from "@/components/ui/card"
import { Linkedin, Mail } from "lucide-react"

const teamMembers = [
  {
    name: "Dr. Arun Kumar",
    role: "Chair",
    image: null,
    bio: "Professor of Electronics Engineering with 20+ years of experience in analog circuit design.",
    linkedin: "#",
    email: "arun.kumar@ieee.org",
  },
  {
    name: "Neha Nair",
    role: "Vice Chair",
    image: null,
    bio: "Associate Professor specializing in VLSI design and semiconductor devices.",
    linkedin: "#",
    email: "neha.nair@ieee.org",
  },
  {
    name: "Rahul Menon",
    role: "Secretary",
    image: null,
    bio: "Research Scholar focused on signal processing and machine learning applications.",
    linkedin: "#",
    email: "rahul.menon@ieee.org",
  },
  {
    name: "Aditya Nair",
    role: "Technical Lead",
    image: null,
    bio: "Industry professional with expertise in embedded systems and IoT solutions.",
    linkedin: "#",
    email: "aditya.nair@ieee.org",
  },
]

function getInitials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
}

export function Team() {
  return (
    <section id="team" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-block rounded-full bg-[var(--cass-green-primary)]/10 px-4 py-1.5 text-sm font-semibold text-[var(--cass-green-primary)]">
            Our Team
          </span>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Executive Committee
          </h2>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            Meet the dedicated professionals leading IEEE CASS Kerala Chapter
            and driving our mission forward.
          </p>
        </div>

        {/* Team Grid */}
        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {teamMembers.map((member) => (
            <Card
              key={member.name}
              className="group overflow-hidden border border-border bg-card shadow-sm transition-all hover:border-[var(--cass-green-primary)]/30 hover:shadow-lg hover:-translate-y-2"
            >
              <CardContent className="p-6 text-center">
                {/* Avatar */}
                <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-[var(--cass-green-primary)] to-[var(--cass-teal)] text-white shadow-lg transition-transform group-hover:scale-105">
                  <span className="text-2xl font-bold">
                    {getInitials(member.name)}
                  </span>
                </div>

                {/* Info */}
                <h3 className="text-lg font-bold text-foreground">
                  {member.name}
                </h3>
                <p className="mt-1 text-sm font-semibold text-[var(--cass-green-primary)]">
                  {member.role}
                </p>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                  {member.bio}
                </p>

                {/* Social Links */}
                <div className="mt-4 flex items-center justify-center gap-3">
                  <a
                    href={member.linkedin}
                    className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-[var(--cass-green-primary)] hover:text-white"
                    aria-label={`${member.name}'s LinkedIn`}
                  >
                    <Linkedin className="h-4 w-4" />
                  </a>
                  <a
                    href={`mailto:${member.email}`}
                    className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-[var(--cass-green-primary)] hover:text-white"
                    aria-label={`Email ${member.name}`}
                  >
                    <Mail className="h-4 w-4" />
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
