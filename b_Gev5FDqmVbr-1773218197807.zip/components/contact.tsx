"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Send, Linkedin, Instagram, ExternalLink } from "lucide-react"

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("[v0] Form submitted:", formData)
    alert("Thank you for your message! We will get back to you soon.")
    setFormData({ name: "", email: "", message: "" })
  }

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  return (
    <section id="contact" className="py-20 lg:py-28 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-block rounded-full bg-[var(--cass-green-primary)]/10 px-4 py-1.5 text-sm font-semibold text-[var(--cass-green-primary)]">
            Contact Us
          </span>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Get in Touch
          </h2>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            Have questions about IEEE CASS Kerala Chapter? We&apos;d love to
            hear from you. Send us a message and we&apos;ll respond as soon as
            possible.
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          {/* Contact Form */}
          <Card className="border border-border shadow-sm">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="mb-2 block text-sm font-medium text-foreground"
                  >
                    Your Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="John Doe"
                    required
                    className="border-border focus:border-[var(--cass-green-primary)] focus:ring-[var(--cass-green-primary)]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="email"
                    className="mb-2 block text-sm font-medium text-foreground"
                  >
                    Email Address
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="john@example.com"
                    required
                    className="border-border focus:border-[var(--cass-green-primary)] focus:ring-[var(--cass-green-primary)]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="message"
                    className="mb-2 block text-sm font-medium text-foreground"
                  >
                    Your Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us how we can help..."
                    rows={5}
                    required
                    className="border-border focus:border-[var(--cass-green-primary)] focus:ring-[var(--cass-green-primary)] resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[var(--cass-green-primary)] hover:bg-[var(--cass-green-primary)]/90 text-white font-semibold"
                >
                  <Send className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="flex flex-col gap-8">
            {/* Email Card */}
            <Card className="border border-border shadow-sm">
              <CardContent className="p-8">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[var(--cass-green-primary)]/10">
                    <Mail className="h-6 w-6 text-[var(--cass-green-primary)]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">
                      Email Us
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      For general inquiries and membership questions
                    </p>
                    <a
                      href="mailto:cass.kerala@ieee.org"
                      className="mt-2 inline-block text-[var(--cass-green-primary)] font-medium hover:underline"
                    >
                      cass.kerala@ieee.org
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Social Media Card */}
            <Card className="border border-border shadow-sm flex-1">
              <CardContent className="p-8">
                <h3 className="text-lg font-semibold text-foreground mb-4">
                  Connect With Us
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Follow us on social media for the latest updates, event
                  announcements, and community news.
                </p>
                <div className="flex flex-wrap gap-3">
                  <a
                    href="#"
                    className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:border-[var(--cass-green-primary)] hover:text-[var(--cass-green-primary)]"
                  >
                    <Linkedin className="h-5 w-5" />
                    LinkedIn
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:border-[var(--cass-green-primary)] hover:text-[var(--cass-green-primary)]"
                  >
                    <Instagram className="h-5 w-5" />
                    Instagram
                  </a>
                  <a
                    href="https://ieee.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:border-[var(--cass-green-primary)] hover:text-[var(--cass-green-primary)]"
                  >
                    <ExternalLink className="h-5 w-5" />
                    IEEE.org
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
